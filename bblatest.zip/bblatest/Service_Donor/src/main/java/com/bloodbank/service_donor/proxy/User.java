package com.bloodbank.service_donor.proxy;

import java.util.List;

import com.bloodbank.service_donor.enums.Role;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class User {
	private String username;
	private String password;
	private List<Role> roles;
}
