package com.bloodbank.service_donor.enums;

public enum Role {
	ADMIN,DONOR,CONSUMER;
	
	private String role;
	
	public String getRole() {
		return role;
	}
}
