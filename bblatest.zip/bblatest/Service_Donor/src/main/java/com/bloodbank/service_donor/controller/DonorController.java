package com.bloodbank.service_donor.controller;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bloodbank.service_donor.domain.Transaction;
import com.bloodbank.service_donor.proxy.DonorProxy;
import com.bloodbank.service_donor.service.DonorServices;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@RefreshScope
@RestController
@RequestMapping("/donor")
@Tag(name = "Donor Controller", description = "APIs for Donor management")
public class DonorController {
	@Autowired
	private DonorServices donorService;

	@Value("${message:Hello default}")
	private String message;

	@GetMapping("/message")
	String getMessage() {
		return this.message;
	}

	@PostMapping("/saveDonor")
	@Operation(summary = "SaveDonor", description = "Add new Donor to the System.")
	public String saveDonor(@Valid @RequestBody DonorProxy donor) {
		return donorService.saveDonor(donor);
	}

	@GetMapping("/getDonorByUsername/{uname}")
	@Operation(summary = "GetDonorByUsername", description = "Provides a donor's Details.")
	public DonorProxy getDonorByUsername(@PathVariable("uname") String uname) {
		return donorService.getDonorByUsername(uname);
	}

	@Operation(summary = "GetAllBloodGroups", description = "Provides all the blood groups.")
	@GetMapping("/getAllBloodGroups")
	public List<String> getAllBloodGroups() {
		return donorService.getAllBloodGroups();
	}

	@Operation(summary = "GetAllDonors", description = "Provides all the donors details.")
	@GetMapping("/getAllDonors")
	public List<DonorProxy> getAllDonors() {
		return donorService.getAllDonors();
	}

	@Operation(summary = "DeleteDonorByUsername", description = "Deletes a particular Donor.")
	@DeleteMapping("/deleteDonorByUsername/{uname}")
	public String deleteDonorByUsername(@PathVariable("uname") String uname) {
		return donorService.deleteDonorByUsername(uname);
	}

	@Operation(summary = "DonateBlood", description = "Donor can donate blood.")
	@PostMapping("/donateBlood")
	public String donateBlood(@RequestBody Transaction transaction) {
		transaction.setTransactionId(UUID.randomUUID().getMostSignificantBits() & Long.MAX_VALUE);
		return donorService.donateBlood(transaction);
	}

	@Operation(summary = "IsDonorUsernameAvailable", description = "Checks if the donor's username ia available or not.")
	@GetMapping("/isDonorUsernameAvailable/{username}")
	public Boolean isDonorUsernameAvailable(@PathVariable("username") String username) {
		System.out.println(donorService.isUsernameAvailable(username));
		return donorService.isUsernameAvailable(username);
	}

}
