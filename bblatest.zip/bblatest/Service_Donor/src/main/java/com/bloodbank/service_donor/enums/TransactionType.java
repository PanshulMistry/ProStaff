package com.bloodbank.service_donor.enums;

public enum TransactionType {
	Donation,
	Consumption
}
 
