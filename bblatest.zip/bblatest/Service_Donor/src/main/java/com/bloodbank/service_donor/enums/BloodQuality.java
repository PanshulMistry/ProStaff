package com.bloodbank.service_donor.enums;

public enum BloodQuality {
	Moderate,
	High,
	VeryHigh;
}
