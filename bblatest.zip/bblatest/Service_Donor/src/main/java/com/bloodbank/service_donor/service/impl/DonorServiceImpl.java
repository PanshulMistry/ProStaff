package com.bloodbank.service_donor.service.impl;

import java.util.ArrayList;
import java.util.List;

import java.util.Optional;

import org.apache.catalina.connector.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.bloodbank.service_donor.domain.Donor;
import com.bloodbank.service_donor.domain.Transaction;
import com.bloodbank.service_donor.enums.ErrorMessageEnum;
import com.bloodbank.service_donor.enums.Role;
import com.bloodbank.service_donor.exceptions.DonorNotFoundException;
import com.bloodbank.service_donor.exceptions.UsernameExistsException;
import com.bloodbank.service_donor.proxy.DonorProxy;
import com.bloodbank.service_donor.proxy.User;
import com.bloodbank.service_donor.repository.DonorRepo;
import com.bloodbank.service_donor.service.DonorServices;
import com.bloodbank.service_donor.utils.MapperUtils;

@Service
public class DonorServiceImpl implements DonorServices{
	
	@Autowired
	private DonorRepo donorRepo;
	
	@Autowired 
	private RestTemplate restTemplate;
	
	@Autowired 
	private BCryptPasswordEncoder encoder;
	
	@Override
	public String saveDonor(DonorProxy donor) {
//		Boolean isUserAvail = restTemplate.getForObject("http://localhost:8080/bank/is-user-name-available/"+donor.getUsername(),
//			    Boolean.class
//			);
		Boolean isAvail = restTemplate.getForObject("http://SERVICE-AUTH/auth/isUsernameAvail/"+donor.getUsername(), Boolean.class);
		if(!isAvail) return null;
		Donor d = MapperUtils.convertValue(donor, Donor.class);
		d.setPassword(encoder.encode(d.getPassword()));
		donorRepo.save(d);
		User user = new User();
		user.setUsername(d.getUsername());
		user.setPassword(d.getPassword());
		List<Role> roles = new ArrayList<>();
		
		roles.add(Role.DONOR);
	
		user.setRoles(roles);
		restTemplate.postForObject("http://SERVICE-AUTH/auth/saveUser", user, String.class);
		// TODO Auto-generated method stub
		return "Donor Saved Successfully.";
	}

	@Override
	public DonorProxy getDonorByUsername(String username) {
		// TODO Auto-generated method stub
		Optional<Donor> op = donorRepo.findById(username);
		if(!op.isPresent()) {
			throw new DonorNotFoundException(ErrorMessageEnum.DONOR_NOT_FOUND.getErrMessage(),ErrorMessageEnum.DONOR_NOT_FOUND.getErrCode());
		} 
		return MapperUtils.convertValue(op.get(), DonorProxy.class);
	}

	@Override
	public String deleteDonorByUsername(String username) {
		// TODO Auto-generated method stub
		Optional<Donor> op = donorRepo.findById(username);
		if(!op.isPresent()) {
			throw new DonorNotFoundException(ErrorMessageEnum.DONOR_NOT_FOUND.getErrMessage(),ErrorMessageEnum.DONOR_NOT_FOUND.getErrCode());
		}
		donorRepo.deleteById(username);
		return "Donor Deleted Successfully.";
	}

	@Override
	public List<DonorProxy> getAllDonors() {
		
		// TODO Auto-generated method stub
		List<DonorProxy> donorList = MapperUtils.convertListValue(donorRepo.findAll(),DonorProxy.class);
		return donorList;
	}

	@Override
	public String donateBlood(Transaction transaction) {
		// TODO Auto-generated method stub
//		ResponseEntity<String> response = restTemplate.postForEntity("http://localhost:8080/bank/donate-blood",transaction, String.class);
		ResponseEntity<String> response = restTemplate.postForEntity("http://SERVICE-BANK/bank/donate-blood",transaction, String.class);
		
		return response.getBody();
	}

	@Override
	public Boolean isUsernameAvailable(String username) {
		// TODO Auto-generated method stub
		return !donorRepo.existsById(username);
	}

	@Override
	public List<String> getAllBloodGroups() {
//		ResponseEntity<List<String>> resp = restTemplate.exchange("http://localhost:8080/bank/get-all-blood-groups",
//				HttpMethod.GET, null, new ParameterizedTypeReference<List<String>>() {
//				});
//		String[] resp = restTemplate.getForObject("/get-all-blood-groups", String[].class);
		// TODO Auto-generated method stub
		ResponseEntity<List<String>> resp = restTemplate.exchange("http://SERVICE-BANK/bank/get-all-blood-groups",
				HttpMethod.GET, null, new ParameterizedTypeReference<List<String>>() {
				});
		return resp.getBody();
	}

}
