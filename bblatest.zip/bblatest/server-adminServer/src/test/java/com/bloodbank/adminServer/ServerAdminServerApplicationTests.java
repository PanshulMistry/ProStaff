package com.bloodbank.adminServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerAdminServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
