package com.bloodbank.service_consumer.controller;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bloodbank.service_consumer.domain.Transaction;
import com.bloodbank.service_consumer.proxy.ConsumerProxy;
import com.bloodbank.service_consumer.service.ConsumerService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/consumer")
@Tag(name = "Consumer Controller", description = "API for Consumer management")
public class ServiceConsumerController {

	@Autowired
	private ConsumerService consumerService;
	
	@GetMapping("/getAllConsumer")
	@Operation(summary = "GetAllConsumers", description = "Gives all consumers and its details.")
	public List<ConsumerProxy> getAllConsumer() {
		return consumerService.getAllConsumer();
	}
	
	@GetMapping("/getConsumerByUsername/{username}")
	@Operation(summary = "GetConsumerByUsername", description = "Provides Details of a particular Consumer.")
	public ConsumerProxy getConsumerByUsername(@PathVariable("username") String username) {
		return consumerService.getConsumerByUsername(username);
	}
	
	@DeleteMapping("/deleteConsumerByUsername/{username}")
	@Operation(summary = "DeleteConsumerByUsername", description = "Deletes a particular Consumer.")
	public String deleteConsumerByUsername(@PathVariable("username") String username) {
		return consumerService.deleteConsumerByUsername(username);
	}
	
	@PostMapping("/saveConsumer")
	@Operation(summary = "SaveConsumer", description = "Adds a new Consumer.")
	public ConsumerProxy saveConsumer(@RequestBody ConsumerProxy consumer) {
		return consumerService.saveConsumer(consumer);
	}
	
	@PostMapping("/requestBlood")
	@Operation(summary = "RequestBlood", description = "Consumer can make a request for blood.")
	public String requestBlood(@RequestBody Transaction transaction) {
		 transaction.setTransactionId(UUID.randomUUID().getMostSignificantBits() & Long.MAX_VALUE);
		return consumerService.requestBlood(transaction);
	}
	
	@GetMapping("/getAllBloodGroups")
	@Operation(summary = "GetAllBloodGroups", description = "Provides all the blood groups.")
	public List<String> getAllBloodGroups(){
		return consumerService.getAllBloodGroups();
	}
	
	@GetMapping("/isConsumerUsernameAvailable/{username}")
	@Operation(summary = "IsConsumerUsernameAvailable", description = "Checks if a consumer's username is available or not.")
	public Boolean isConsumerUsernameAvailable(@PathVariable("username") String username) {
		return consumerService.isConsumerUsernameAvailable(username);
	}
}
