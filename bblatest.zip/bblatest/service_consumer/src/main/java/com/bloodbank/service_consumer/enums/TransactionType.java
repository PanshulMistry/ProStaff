package com.bloodbank.service_consumer.enums;

public enum TransactionType {

	Donation,
	Consumption
}
