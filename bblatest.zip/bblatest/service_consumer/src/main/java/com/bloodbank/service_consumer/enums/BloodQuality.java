package com.bloodbank.service_consumer.enums;

public enum BloodQuality {

	Moderate,
	High,
	VeryHigh;
}
