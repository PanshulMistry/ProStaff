package com.bloodbank.service_bank.enums;

public enum TransactionType {
	
	Donation,
	Consumption
	
}
