package com.bloodbank.service_bank.enums;

public enum BloodQuality {
	Moderate,
	High,
	VeryHigh;
}
