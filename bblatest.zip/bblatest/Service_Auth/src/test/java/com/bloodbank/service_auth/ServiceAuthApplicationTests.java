package com.bloodbank.service_auth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceAuthApplicationTests {

	@Test
	void contextLoads() {
	}

}
