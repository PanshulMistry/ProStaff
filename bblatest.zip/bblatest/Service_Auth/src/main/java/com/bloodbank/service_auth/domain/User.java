package com.bloodbank.service_auth.domain;

import java.util.List;

import com.bloodbank.service_auth.enums.Role;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class User {
	
	@Id
	private String username;
	private String password;
	private List<Role> roles;
}	
