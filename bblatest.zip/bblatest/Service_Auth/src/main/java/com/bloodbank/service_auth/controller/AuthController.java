package com.bloodbank.service_auth.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bloodbank.service_auth.domain.User;
import com.bloodbank.service_auth.proxy.LoginRequest;
import com.bloodbank.service_auth.proxy.LoginResponse;
import com.bloodbank.service_auth.proxy.ValidationRequest;
import com.bloodbank.service_auth.service.AuthService;

import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/auth")
@Tag(name = "Auth Controller", description = "API for Auth management")
public class AuthController {
	
	@Autowired
	private AuthService authService;
	
	@PostMapping("/login")
	@Operation(summary = "Login", description = "Login Request For all the users.")
	public ResponseEntity<LoginResponse> login(@RequestBody LoginRequest logReq) {
		return new ResponseEntity<LoginResponse>(authService.login(logReq),HttpStatus.OK);
	}
	
	@Hidden
	@PostMapping("/isTokenValid")
	public Integer isTokenValid(@RequestBody ValidationRequest req) {
		return authService.isTokenValid(req);
	}
	
	@Hidden
	@PostMapping("/saveUser")
	public String saveUser(@RequestBody User user) {
		return authService.saveUser(user);
	}
	
	@Hidden
	@GetMapping("/isUsernameAvail/{uname}")
	public Boolean isUsernameAvail(@PathVariable String uname) {
		return authService.isUsernameAvail(uname);
	}
}
