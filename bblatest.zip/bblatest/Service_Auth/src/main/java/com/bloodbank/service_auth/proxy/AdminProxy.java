package com.bloodbank.service_auth.proxy;

import com.bloodbank.service_auth.enums.Gender;
import com.bloodbank.service_auth.enums.Role;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(Include.NON_NULL)
public class AdminProxy {
	
	private Long id;
	private String name;
	
	
	private Gender gender;
	private String username;
	private String password;
	
	private Role role;
	private Boolean isActive;

}
