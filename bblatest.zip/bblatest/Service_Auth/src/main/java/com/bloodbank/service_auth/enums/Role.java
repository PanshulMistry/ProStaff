package com.bloodbank.service_auth.enums;

public enum Role {
	ADMIN,DONOR,CONSUMER;
	
	private String role;
	
	public String getRole() {
		return role;
	}
}
 

