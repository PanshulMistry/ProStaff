package com.bloodbank.service_auth.enums;

public enum Gender {
	MALE, FEMALE, OTHER;
}
