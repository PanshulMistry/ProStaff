package com.bloodbank.service_auth.service;

import com.bloodbank.service_auth.domain.User;
import com.bloodbank.service_auth.proxy.LoginRequest;
import com.bloodbank.service_auth.proxy.LoginResponse;
import com.bloodbank.service_auth.proxy.ValidationRequest;

public interface AuthService {
	public LoginResponse login(LoginRequest logReq);
	
	public Integer isTokenValid(ValidationRequest req); 
	
	public Boolean isUsernameAvail(String username);
	
	public String saveUser(User user);
}
