package com.bloodbank.service_auth.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.bloodbank.service_auth.domain.User;
import com.bloodbank.service_auth.enums.Role;
import com.bloodbank.service_auth.proxy.LoginRequest;
import com.bloodbank.service_auth.proxy.LoginResponse;
import com.bloodbank.service_auth.proxy.ValidationRequest;
import com.bloodbank.service_auth.repository.UserRepo;
import com.bloodbank.service_auth.service.AuthService;
import com.bloodbank.service_auth.utils.JwtUtils;

@Service
public class AuthServiceImpl implements AuthService{
	
	@Autowired
	private AuthenticationManager authManager;
	
	@Autowired
	private JwtUtils jwtUtils;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private UserRepo repo;

	@Override
	public LoginResponse login(LoginRequest logReq) {
		// TODO Auto-generated method stub
		Authentication auth = new UsernamePasswordAuthenticationToken(logReq.getUsername(), logReq.getPassword());
		Authentication verfAuth = authManager.authenticate(auth);

		if (verfAuth.isAuthenticated()) {
			User user = repo.findById(logReq.getUsername()).get();
			List<String> rolesString = new ArrayList<>();
			for(Role r : user.getRoles()) {
				rolesString.add(r.toString());
			}
			return new LoginResponse(logReq.getUsername(), jwtUtils.generateToken(logReq.getUsername(), rolesString));
		}

		return new LoginResponse(logReq.getUsername(), "Request Failed");
	}

	@Override
	public Integer isTokenValid(ValidationRequest req) {
		
		// 0 authorized and authenticated
		// 1 not authenticated and not authorized
		// 2 authenticated but not authorized
		
		try {
			String token = req.getJwt_token();
			token = token.substring(7);
			String path = req.getPath();
			System.out.println(path);
			
			if(!repo.existsById(jwtUtils.extractUserName(token)) || jwtUtils.isTokenExpired(token)) return 1;
			
			// not expired and username exist
			// checking for authorization
			if(path.equals("admin") && jwtUtils.extractRoles(token).contains(Role.ADMIN.toString()))
			{
				return 0;
			}
			else if(path.equals("consumer") && jwtUtils.extractRoles(token).contains(Role.CONSUMER.toString()))
			{
				return 0;
			}
			else if(path.equals("donor") && jwtUtils.extractRoles(token).contains(Role.DONOR.toString()))
			{
				return 0;
			}
			
			return 2;
		} catch (Exception e) {
			return 1;
		}
		
	}

	@Override
	public Boolean isUsernameAvail(String username) {
		// TODO Auto-generated method stub
		
		return !repo.existsById(username);
	}

	@Override
	public String saveUser(User user) {
		repo.save(user);
		return "Saved User.";
	}

}
