package com.bloodbank.config_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
