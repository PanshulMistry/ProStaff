package com.bloodbank.service_gateway;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.GatewayFilterFactory;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.web.client.RestTemplate;

public class ValidRequest implements GatewayFilterFactory {
	
	
	private static List<String> whiteList;
	
	static {
		whiteList = new ArrayList<>();
		whiteList.add("/auth/login");
	}
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Override
	  public GatewayFilter apply(Object config) {
	    return (exchange, chain) -> {
	      ServerHttpRequest request = exchange.getRequest();
	      
	      String path = request.getPath().toString();
	      System.err.println(path);
	      if(path.contains("swagger-ui") || path.contains("v3/api-docs"))
	      {

	    	  String dev_key = "JmX$9pQ@Gv2N#L8zKf!YTR5cWxt1bMdV7Mw&Z36P*AoEhCyD%UFHnBsrjlkOgXaVqT47NpY!X$Lm@J9KfWc2Z5bR6dM83&owP*AhCFDU%";
	    	  System.err.println(path);
	    	  if(request.getHeaders().containsKey("Devkey") && request.getHeaders().get("Devkey").get(0).equals(dev_key))
	    	  {
	    		  return chain.filter(exchange);
	    	  }
	    	  
    		  exchange.getResponse().setStatusCode(HttpStatusCode.valueOf(404));
    		  return exchange.getResponse().setComplete();
	      }
	      
    	  if(path.contains("/auth"))
    	  {
    		  if(whiteList.contains(path))
    		  {
    			  return chain.filter(exchange);
    		  }
    		  exchange.getResponse().setStatusCode(HttpStatusCode.valueOf(404));
	    	  return exchange.getResponse().setComplete();
    	  }
	      
	      
	      if (request.getHeaders().containsKey("Authorization")){
	    	  //not accessible to public   
	    	  
	    	  path = path.substring(1);
	    	  path = path.substring(0, path.indexOf("/"));
	    	  
	    	  ValidationRequest req = new ValidationRequest(request.getHeaders().get("Authorization").get(0), path);
	    	  
	    	  Integer statusCode = restTemplate.postForObject("http://localhost:9095/auth/isTokenValid", req , Integer.class);
	    	  if(statusCode == 1)
	    	  {
	    		  exchange.getResponse().setStatusCode(HttpStatusCode.valueOf(401));
		    	  return exchange.getResponse().setComplete();
	    	  }
	    	  else if(statusCode == 2)
	    	  {
	    		  exchange.getResponse().setStatusCode(HttpStatusCode.valueOf(403));
		    	  return exchange.getResponse().setComplete();
	    	  }
	    	   
	      } else {
	    	  exchange.getResponse().setStatusCode(HttpStatusCode.valueOf(401));
	    	  return exchange.getResponse().setComplete();
	      }

	      return chain.filter(exchange);
	    };
	  }

	  
	@Override
	public Class<Config> getConfigClass() {
		return Config.class;
	}

	@Override
	public Config newConfig() {
		Config c = new Config();
		return c;
	}

	public static class Config {}
	  
	
	}
