package com.bloodbank.service_gateway;

public class ValidationRequest {
	
	private String jwt_token;
	private String path;
	
	
	
	public ValidationRequest(String jwt_token, String path) {
		super();
		this.jwt_token = jwt_token;
		this.path = path;
	}
	public String getJwt_token() {
		return jwt_token;
	}
	public void setJwt_token(String jwt_token) {
		this.jwt_token = jwt_token;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	
}
