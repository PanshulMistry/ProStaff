package com.bloodbank.service_admin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bloodbank.service_admin.enums.BloodQuality;
import com.bloodbank.service_admin.enums.BloodType;
import com.bloodbank.service_admin.enums.TransactionType;
import com.bloodbank.service_admin.proxy.AdminProxy;
import com.bloodbank.service_admin.proxy.BloodSampleProxy;
import com.bloodbank.service_admin.proxy.TransactionProxy;
import com.bloodbank.service_admin.service.AdminService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/admin")
@Tag(name = "Admin Controller", description = "API for Admin management")
public class AdminController {
	@Autowired
	private AdminService service;
	
	@PostMapping("/register")
	@Operation(summary = "RegisterAdmin", description = "Adds a new admin.")
	public ResponseEntity<AdminProxy> registerAdmin(@RequestBody AdminProxy adminProxy){
		return new ResponseEntity<AdminProxy>(service.saveAdmin(adminProxy), HttpStatus.CREATED);
	}

	@GetMapping("/getAllAdmin")
	@Operation(summary = "GetAllAdmin", description = "Provides all the admin's details.")
	public ResponseEntity<List<AdminProxy>> getAllAdmin() {
		return new ResponseEntity<List<AdminProxy>>(service.getAllAdmin(), HttpStatus.OK);
	}

	@PostMapping("getAdmin/{username}")
	@Operation(summary = "GetAdmin", description = "Provides details of a particular admin.")
	public ResponseEntity<AdminProxy> getAdmin(@PathVariable String username) {
		return new ResponseEntity<AdminProxy>(service.getAdminByUsername(username), HttpStatus.OK);
	}

	@GetMapping("/deleteAdmin/{username}")
	@Operation(summary = "DeleteAdmin", description = "Deletes a particular admin.")
	public ResponseEntity<String> deleteAdmin(@PathVariable String username) {
		return new ResponseEntity<String>(service.deleteAdminByUsername(username), HttpStatus.OK);
	}
	
	@DeleteMapping("/deleteUser/{username}")
	@Operation(summary = "DeleteUser", description = "Deletes a user.")
	public ResponseEntity<String> deleteUser(@PathVariable("username") String username) {
		return new ResponseEntity<String>(service.deleteUser(username), HttpStatus.OK);
	}
	
	@Operation(summary = "GetAllBloodGroups", description = "Provides all the blood groups.")
	@GetMapping("/get-all-blood-groups")
	public List<String> getAllBloodGroups(){
		return service.getAllBloodGroups();
	}
	
	@Operation(summary = "GetAllBloodGroupSamples", description = "Provides details of the blood samples stored from donors.")
	@GetMapping("/get-all-blood-group-samples/{sample}")
	public List<BloodSampleProxy> getAllBloodGroupSamples(@PathVariable("sample") BloodType bloodGroup){
		return service.getAllBloodGroupSamples(bloodGroup);
	}
	
	@Operation(summary = "GetAllBloodGroups", description = "Provides all the blood groups.")
	@GetMapping("/get-all-blood-group-transactions/{bloodGroup}")
	public List<TransactionProxy> getAllBloodGroupTransactions(@PathVariable("bloodGroup") BloodType bloodGroup){
		return service.getAllBloodGroupTransactions(bloodGroup);
	}
	
	@Operation(summary = "GetAllBloodGroupTransactionsAsPerType", description = "Provides details of blood groups transactions as per the blood type.")
	@GetMapping("/get-all-blood-group-transactions-asper-type/{bloodGroup}/{type}")
	public List<TransactionProxy> getAllBloodGroupTransactionsAsPerType(@PathVariable("bloodGroup") BloodType bloodGroup, @PathVariable("type") TransactionType type){
		return service.getAllBloodGroupTransactionsAsPerType(bloodGroup, type);
	}
	
	@Operation(summary = "GetAllBloodGroupSamplesAsPerQuality", description = "Provides details of blood group samples as per their quality.")
	@GetMapping("/get-all-blood-group-samples-asper-quality/{bloodGroup}/{quality}")
	public List<BloodSampleProxy> getAllBloodGroupSamplesAsPerQuality(@PathVariable("bloodGroup") BloodType bloodGroup, @PathVariable("quality") BloodQuality quality){
		return service.getAllBloodGroupSamplesAsPerQuality(bloodGroup, quality);
	}
	
	@Operation(summary = "AddBloodGroup", description = "Adds a new blood group.")
	@PostMapping("/add-blood-group/{newBloodGroup}")
	public String addBloodGroup(@PathVariable("newBloodGroup") BloodType newBloodGroup){
		return service.addBloodGroup(newBloodGroup);
	}
	
	@Operation(summary = "IsAdminExist", description = "Checks if the admin exists or not.")
	@GetMapping("/is-admin-exist/{userName}")
	public Boolean isAdminExists(@PathVariable String userName) {
		return service.isAdminExists(userName);
	}
	
	
	
}
