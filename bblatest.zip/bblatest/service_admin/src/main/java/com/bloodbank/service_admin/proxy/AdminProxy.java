package com.bloodbank.service_admin.proxy;

import com.bloodbank.service_admin.enums.Gender;
import com.bloodbank.service_admin.enums.Role;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(Include.NON_NULL)
public class AdminProxy {
	
	private Long id;
	private String name;
	
	@Enumerated(EnumType.STRING)
	private Gender gender;
	private String username;
	private String password;
	
	@Enumerated(EnumType.STRING)
	private Role role;
	private Boolean isActive;

}
