package com.bloodbank.service_admin.service;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient("SERVICE-BANK")
public interface BankService  {
	
	@GetMapping ("/bank/get-all-blood-groups")
	public List<String> getAllBloodGroups();
}
