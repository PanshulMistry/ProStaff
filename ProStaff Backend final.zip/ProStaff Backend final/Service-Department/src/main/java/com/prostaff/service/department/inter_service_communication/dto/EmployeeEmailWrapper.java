package com.prostaff.service.department.inter_service_communication.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class EmployeeEmailWrapper {
	
	String employeeEmail;
	
}
