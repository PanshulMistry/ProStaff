package com.prostaff.service.notification.inter_service_communication.dto;

import lombok.Data;

@Data
public class AdminEmailWrapper {
	String adminEmail;
}
