package com.prostaff.service_organization.inter_service_communication.dto;

import java.sql.Date;

public class GrantedLeaveRequest {
	
	String employeeEmail; 
	String adminEmail; 
	Date date; 
	
}
