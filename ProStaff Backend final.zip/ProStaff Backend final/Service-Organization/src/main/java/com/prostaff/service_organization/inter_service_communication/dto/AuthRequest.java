package com.prostaff.service_organization.inter_service_communication.dto;

public class AuthRequest {
	
	String jwtToken;
	String path; 
	
}
