package com.prostaff.service_organization.inter_service_communication.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class EmployeeEmailWrapper {
	
	String employeeEmail;
	
}
