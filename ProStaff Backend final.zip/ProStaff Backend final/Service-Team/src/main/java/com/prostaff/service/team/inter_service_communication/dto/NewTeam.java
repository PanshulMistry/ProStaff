package com.prostaff.service.team.inter_service_communication.dto;

import lombok.Data;

@Data
public class NewTeam {

	String name;
	String description;
	String adminEmail;
}
