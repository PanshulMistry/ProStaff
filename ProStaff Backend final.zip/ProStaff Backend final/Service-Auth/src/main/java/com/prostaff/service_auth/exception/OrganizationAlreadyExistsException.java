package com.prostaff.service_auth.exception;

public class OrganizationAlreadyExistsException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

}
