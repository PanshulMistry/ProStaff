package com.prostaff_service_admin_logger.inter_service_communication.enums;

public enum LeaveRequestStatus {
	ACCEPTED, REJECTED, PENDING
}
