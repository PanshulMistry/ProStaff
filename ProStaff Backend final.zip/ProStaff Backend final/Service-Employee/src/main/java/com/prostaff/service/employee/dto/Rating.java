package com.prostaff.service.employee.dto;

import lombok.Data;

@Data
public class Rating
{
	Integer punctuality; 
	Integer performance; 
	Integer softSkills; 
	Integer creativity;
}
