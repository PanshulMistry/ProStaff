import { Component, OnInit } from '@angular/core';
import { Employee, EmployeeBasicInformation, EmployeeService } from '../employee.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-employee-dashboard',
  standalone: false,
  templateUrl: './employee-dashboard.component.html',
  styleUrl: './employee-dashboard.component.css'
})
export class EmployeeDashboardComponent implements OnInit {
  organizationName: string = '';
  organizationLogo: string = '';

  constructor(private employeeService: EmployeeService, private route: ActivatedRoute) {}

  adminEmail: string = '';
  jwtToken: string = '';  // Ensure it's always a string

  employee: Employee = {
    email: '',
    fullName: '',
    gender: 'OTHER', // Default value
    skills: [],
    reportingManager: '',
    phoneNumber: '',
    dob: '',
    profileImage: '',
    joiningDate: '',
    emergencyContact: '',
    bankDetail: {
      bankName: '',
      ifscCode: '',
      accountNumber: '',
      branch: ''
    },
    rating: {
      punctuality: 0,
      performance: 0,
      softSkills: 0,
      creativity: 0
    },
    age: 0,
    department: {
      id: 0,
      name: '',
      description: '',
      employeeCount: 0
    },
    designation: {
      id: 0,
      name: '',
      description: '',
      employeeCount: 0
    },
    teams: [],
    address: ''
  };
  

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.adminEmail = params['adminEmail'];
    });

    // Retrieve JWT token and ensure it's a string
    this.jwtToken = localStorage.getItem('jwt') || '';

    if (this.adminEmail && this.jwtToken) {
      console.log('Admin email:', this.adminEmail);
      console.log('JWT Token:', this.jwtToken);
      this.getOrganizationDetails();
      this.getEmployeeDetails();
    } else {
      console.error('Admin email or JWT token missing');
    }
  }
  getEmployeeDetails() {
    if (!this.jwtToken) {
      console.error('JWT token is missing');
      return;
    }
  
    this.employeeService.getEmployeeInformation(this.adminEmail, this.jwtToken).subscribe({
      next: (data: Employee) => {
        this.employee = data;
        console.log('Employee Details:', this.employee);
  
        // Convert profileImage (byte array) to Base64 if needed
        if (this.employee.profileImage && !this.employee.profileImage.startsWith('http')) {
          this.employee.profileImage = 'data:image/png;base64,' + this.employee.profileImage;
        }
      },
      error: (err) => {
        console.error('Failed to load employee details', err);
      }
    });
  }
  
  

  getOrganizationDetails() {
    this.employeeService.getOrganizationDetails(this.adminEmail, this.jwtToken).subscribe({
      next: (data) => {
        this.organizationName = data.organizationName;
        this.organizationLogo = 'data:image/png;base64,' + data.image;  // Convert byte array to Base64
      },
      error: (err) => {
        console.error('Failed to load organization details', err);
      }
    });
  }
}
