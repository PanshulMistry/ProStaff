import { Injectable } from '@angular/core';

// src/app/services/auth.service.ts

import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private baseUrl = 'http://localhost:5555';

  constructor(private http: HttpClient) {}

  // Login API
  login(email: string, password: string): Observable<{ jwt: string; role: string }> {
    const url = `${this.baseUrl}/auth/login`;
    const body = { email, password };
    // console.log('jwt:',this.jwt)
    return this.http.post<{ jwt: string; role: string }>(url, body).pipe(
      catchError(this.handleError)
    );
  }

  // Verify Payment API
  verifyPayment(
    details: {
      razorpay_order_id: string;
      razorpay_payment_id: string;
      razorpay_signature: string;
      organizationName: string;
      adminFullName: string;
      adminEmail: string;
    },
    orgImage: File
  ): Observable<boolean> {
    const url = `${this.baseUrl}/auth/verify-payment`;
  
    const formData = new FormData();
    const detailsBlob = new Blob([JSON.stringify(details)], { type: 'application/json' });
    formData.append('details', detailsBlob); // Appending JSON as a string
    formData.append('orgImage', orgImage); // File upload
  
    // ✅ No headers needed here
    return this.http.post<boolean>(url, formData).pipe(
      catchError(this.handleError)
    );
  }
  

  // Error Handling
  private handleError(error: HttpErrorResponse) {
    console.error('API Error:', error);
    return throwError(() => new Error('Something went wrong; please try again later.'));
  }
}

