import { Component } from '@angular/core';

@Component({
  selector: 'app-register-employee',
  standalone: false,
  templateUrl: './register-employee.component.html',
  styleUrl: './register-employee.component.css'
})
export class RegisterEmployeeComponent {

}
