import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-signup',
  standalone: false,
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent {

  signupForm: FormGroup;
  selectedFile: File | null = null;
  selectedFilePreview: string | null = null;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private authService: AuthService // Inject AuthService
  ) {
    this.signupForm = this.fb.group({
      organizationName: ['', [Validators.required]],
      adminFullName: ['', [Validators.required]],
      adminEmail: ['', [Validators.required, Validators.email]],
      adminPassword: ['', [Validators.required, Validators.minLength(6)]]
    });
  }

  // Handle File Selection
  onFileSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.selectedFile = input.files[0];

      // Preview Image
      const reader = new FileReader();
      reader.onload = () => {
        this.selectedFilePreview = reader.result as string;
      };
      reader.readAsDataURL(this.selectedFile);
    }
  }

  // Form Submission
  onSubmit() {
    this.signupForm.markAllAsTouched();
  
    if (this.signupForm.valid && this.selectedFile) {
      const details = {
        razorpay_order_id: 'sample_order_id', // Replace with actual ID
        razorpay_payment_id: 'sample_payment_id', // Replace with actual ID
        razorpay_signature: 'sample_signature', // Replace with actual Signature
        organizationName: this.signupForm.value.organizationName,
        adminFullName: this.signupForm.value.adminFullName,
        adminEmail: this.signupForm.value.adminEmail
      };
  
      this.authService.verifyPayment(details, this.selectedFile).subscribe(
        (isVerified) => {
          console.log(isVerified);
          
          if (isVerified) {
            console.log('Payment Verified Successfully');
            this.router.navigate(['/']);
          } else {
            console.error('Payment verification failed.');
          }
        },
        (error) => {
          console.error('Verification Error:', error);
        }
      );
    }
  }
  

  navigateToLogin() {
    this.router.navigate(['/']);
  }
}
