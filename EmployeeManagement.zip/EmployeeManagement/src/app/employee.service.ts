import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  private baseUrl = 'http://localhost:5555';  // Update with your API URL

  constructor(private http: HttpClient) {}

  // Method to fetch all organization employees based on adminEmail
  // getAllOrganizationEmployees(adminEmail: string): Observable<EmployeeBasicInformation[]> {
  //   const url = `${this.baseUrl}/employee/get-all-organization-employees`;
  //   const body = [{ adminEmail }];  // Send the adminEmail in the expected body format

  //   return this.http.post<EmployeeBasicInformation[]>(url, body).pipe(
  //     catchError(this.handleError)
  //   );
  // }
  
getAllOrganizationEmployees(adminEmail: string, token: string): Observable<EmployeeBasicInformation[]> {
  const url = `${this.baseUrl}/employee/get-all-organization-employees`;
  const body = { adminEmail };

  // Set headers with Authorization token
  const headers = new HttpHeaders({
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  });

  return this.http.post<EmployeeBasicInformation[]>(url, body, { headers }).pipe(
    catchError(this.handleError)
  );
}

  addEmployee(employeeRegistrationDetail: any, profileImage: File): Observable<boolean> {
    const url = `${this.baseUrl}/employee/add-employee`;

    const formData = new FormData();
    const detailsBlob = new Blob([JSON.stringify(employeeRegistrationDetail)], { type: 'application/json' });
    formData.append('employeeRegistrationDetail', detailsBlob); // Add JSON details
    formData.append('profileImage', profileImage); // Add the profile image

    return this.http.post<boolean>(url, formData).pipe(
      catchError(this.handleError)
    );
  }

  getOrganizationDetails(employeeEmail: string, token: string): Observable<OrganizationDetails> {
    const url = `${this.baseUrl}/organization/get-organization-data`;
    const body = { employeeEmail };

    // Set headers with Authorization token
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    });

    return this.http.post<OrganizationDetails>(url, body, { headers }).pipe(
      catchError(this.handleError)
    );
  }

  // Error handling




  getEmployeeInformation(employeeEmail: string, token: string): Observable<Employee> {
    const url = `${this.baseUrl}/employee/get-employee-information`;
    const body = { employeeEmail };  // Send a single object, not an array
  
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    });
  
    return this.http.post<Employee>(url, body, { headers }).pipe(
      catchError(this.handleError)
    );
  }
  

  // Error handling
  private handleError(error: HttpErrorResponse) {
    console.error('API Error:', error);
    return throwError(() => new Error('Something went wrong; please try again later.'));
  }
}

export interface Employee {
  email: string;
  fullName: string;
  gender: string;
  skills: string[];
  reportingManager: string;
  phoneNumber: string;
  dob: string;
  profileImage: string;
  joiningDate: string;
  emergencyContact: string;
  bankDetail: {
    bankName: string;
    ifscCode: string;
    accountNumber: string;
    branch: string;
  };
  rating: {
    punctuality: number;
    performance: number;
    softSkills: number;
    creativity: number;
  };
  age: number;
  department: {
    id: number;
    name: string;
    description: string;
    employeeCount: number;
  };
  designation: {
    id: number;
    name: string;
    description: string;
    employeeCount: number;
  };
  teams: Array<{
    id: number;
    name: string;
    description: string;
    employeeCount: number;
  }>;
  address: string;
}

export interface OrganizationDetails {
  organizationName: string;
  image: string;  // Base64 string for navbar display
}

// Define the Employee model
export interface EmployeeBasicInformation {
  fullName: string;
  email: string;
  gender: 'MALE' | 'FEMALE' | 'OTHER'; // Enum for gender
  age: number;
  profileImage: string;
  department: string;
  designation: string;
}
