import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Employee, EmployeeBasicInformation, EmployeeService } from '../employee.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-admin-dashboard',
  standalone: false,
  templateUrl: './admin-dashboard.component.html',
  styleUrl: './admin-dashboard.component.css'
})
export class AdminDashboardComponent implements OnInit {
  employeeForm: FormGroup;
  showForm = false;
  employees: EmployeeBasicInformation[] = [];
  adminEmail: string = '';
  jwtToken: string | null = null;
  organizationName: string = '';
  organizationLogo: string = '';
  
    constructor(private fb: FormBuilder, private employeeService: EmployeeService, private route: ActivatedRoute) {
    this.employeeForm = this.fb.group({
      id: ['', Validators.required],
      name: ['', [Validators.required, Validators.minLength(3)]],
      position: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    // Get adminEmail from query parameters
    this.route.queryParams.subscribe(params => {
      this.adminEmail = params['adminEmail'];
    });
  
    // Retrieve JWT token from localStorage (Ensure it's a string)
    this.jwtToken = localStorage.getItem('jwt') || '';
  
    if (this.adminEmail && this.jwtToken) {
      console.log('Admin email:', this.adminEmail);
      console.log('JWT Token:', this.jwtToken);
      this.getOrganizationDetails();
      this.getEmployees();
    } else {
      console.error('Admin email or JWT token missing');
    }
  }
  

  getOrganizationDetails() {
    this.employeeService.getOrganizationDetails(this.adminEmail, this.jwtToken ?? '').subscribe({
      next: (data) => {
        this.organizationName = data.organizationName;
        this.organizationLogo = 'data:image/png;base64,' + data.image;  // Convert byte array to Base64
      },
      error: (err) => {
        console.error('Failed to load organization details', err);
      }
    });    
  }


  getEmployees(): void {
    if (!this.jwtToken) {
      console.error('JWT Token is missing');
      return;
    }

    this.employeeService.getAllOrganizationEmployees(this.adminEmail, this.jwtToken).subscribe({

      next: (data) => {
        console.log('Fetched Employees:', data);
        this.employees = data;
      },
      error: (err) => {
        console.error('Error fetching employees:', err);
      }
    });
  }
 
  addEmployee(): void {
    if (this.employeeForm.valid) {
      this.employees.push(this.employeeForm.value);
      this.employeeForm.reset();
      this.showForm = false;
    }
  }
 
  toggleForm(): void {
    this.showForm = !this.showForm;
  }
 
  logout(): void {
    console.log('Logout clicked');
  }
}
