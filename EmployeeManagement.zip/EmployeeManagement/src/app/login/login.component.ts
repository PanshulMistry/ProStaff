import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service'; // Import the AuthService

@Component({
  selector: 'app-login',
  standalone: false,
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  loginForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private authService: AuthService // Inject AuthService
  ) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }

  navigateToSignup() {
    this.router.navigate(['/signup']);
  }

  onSubmit() {
    if (this.loginForm.valid) {
      const { email, password } = this.loginForm.value;
  
      this.authService.login(email, password).subscribe(
        (response) => {
          console.log('Login Response:', response); 
  
          if (response && response.jwt) {
            localStorage.setItem('jwt', response.jwt); 
            localStorage.setItem('role', response.role); 
            
            if (response.role === 'ADMIN') {
              console.log('Admin email:', email);
              this.router.navigate(['/adminDashboard'], { queryParams: { adminEmail: email } });
            } else {
              this.router.navigate(['/employeeDashboard'], { queryParams: { adminEmail: email } });
            }
          } else {
            console.error('Invalid login response:', response);
          }
        },
        (error) => {
          console.error('Login Error:', error);
        }
      );
    }
  }
  
}
