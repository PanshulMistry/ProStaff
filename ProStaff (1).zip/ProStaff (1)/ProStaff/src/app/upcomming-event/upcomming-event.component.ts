import { Component } from '@angular/core';

@Component({
  selector: 'app-upcomming-event',
  standalone: false,
  templateUrl: './upcomming-event.component.html',
  styleUrl: './upcomming-event.component.css'
})
export class UpcommingEventComponent {
  events = [
    { title: "Holi", date: "28/04/2022", description: "Colour Celebration" },
    { title: "Diwali", date: "28/04/2022", description: "Firecracker Celebration" },
    { title: "Kite Flying", date: "28/04/2022", description: "Kite Flying" },
    { title: "Navratri", date: "28/04/2022", description: "Playing Garba" },
    { title: "Rangoli", date: "28/04/2022", description: "Create Rangoli" },
    { title: "Mehendi", date: "28/04/2022", description: "Create Mehendi" },
    { title: "Free Dress", date: "28/04/2022", description: "Dress Code" }
  ];

  deleteEvent(index: number) {
    if (confirm("Are you sure you want to delete this event?")) {
      this.events.splice(index, 1);
    }
  }

  addEvent() {
    const newEvent = {
      title: "New Event",
      date: "01/05/2022",
      description: "New Event Description"
    };
    this.events.push(newEvent);
  }
}
