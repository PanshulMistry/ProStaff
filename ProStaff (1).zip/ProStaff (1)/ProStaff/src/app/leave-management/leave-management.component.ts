import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-leave-management',
  standalone: false,
  templateUrl: './leave-management.component.html',
  styleUrl: './leave-management.component.css'
})
export class LeaveManagementComponent implements OnInit {
  leaves = [
    {
      id: '27219',
      name: 'yabsib abebe',
      reason: 'Attend a family function',
      leaveDate: '28/04/2022',
      leaveType: 'Leave',
      requestDate: '28/04/2022'
    },
    {
      id: '37218',
      name: 'fewan fesfsye',
      reason: 'Attend a family function',
      leaveDate: '28/04/2022',
      leaveType: 'Leave',
      requestDate: '28/04/2022'
    },
    {
      id: '47217',
      name: 'AAMANEL BEYENE',
      reason: 'Feeling Sick',
      leaveDate: '28/04/2022',
      leaveType: 'Leave',
      requestDate: '28/04/2022'
    },
    {
      id: '57216',
      name: 'teddy avilay',
      reason: 'Going on Vacation',
      leaveDate: '28/04/2022',
      leaveType: 'Leave',
      requestDate: '28/04/2022'
    },
    {
      id: '67215',
      name: 'redwan husen',
      reason: 'Feeling Sick',
      leaveDate: '28/04/2022',
      leaveType: 'Leave',
      requestDate: '28/04/2022'
    },
    {
      id: '77214',
      name: 'abel beyne',
      reason: 'Feeling Sick',
      leaveDate: '28/04/2022',
      leaveType: 'Unpaid Leave',
      requestDate: '28/04/2022'
    },
    {
      id: '87213',
      name: 'tomesagn melak',
      reason: 'Feeling Sick',
      leaveDate: '28/04/2022',
      leaveType: 'Unpaid Leave',
      requestDate: '28/04/2022'
    }
  ];

  constructor() {}
  ngOnInit(): void {
  }

  approveLeave(leave: any) {
    alert(`Leave approved for: ${leave.name}`);
    // Logic to update or remove from array, etc.
  }

  rejectLeave(leave: any) {
    alert(`Leave rejected for: ${leave.name}`);
    // Logic to update or remove from array, etc.
  }
}
