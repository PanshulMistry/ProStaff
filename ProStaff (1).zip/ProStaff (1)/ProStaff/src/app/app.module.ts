import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration, withEventReplay } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmployeeManagementComponent } from './employee-management/employee-management.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { ViewProfileComponent } from './view-profile/view-profile.component';
import { LeaveManagementComponent } from './leave-management/leave-management.component';
import { UpcommingEventComponent } from './upcomming-event/upcomming-event.component';
import { DepartmentComponent } from './department/department.component';
import { SideMenuBarComponent } from './side-menu-bar/side-menu-bar.component';
import { NavbarComponent } from './navbar/navbar.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { HomePageComponent } from './home-page/home-page.component';
import { NotificationComponent } from './notification/notification.component';
import { RoughWorkComponent } from './rough-work/rough-work.component';
import { TeamsComponent } from './teams/teams.component';

@NgModule({
  declarations: [
    AppComponent,
    EmployeeManagementComponent,
    AddEmployeeComponent,
    ViewProfileComponent,
    LeaveManagementComponent,
    UpcommingEventComponent,
    DepartmentComponent,
    SideMenuBarComponent,
    NavbarComponent,
    ContactUsComponent,
    HomePageComponent,
    NotificationComponent,
    RoughWorkComponent,
    TeamsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [
    provideClientHydration(withEventReplay())
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
