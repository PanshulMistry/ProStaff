import { Component } from '@angular/core';

@Component({
  selector: 'app-notification',
  standalone: false,
  templateUrl: './notification.component.html',
  styleUrl: './notification.component.css'
})
export class NotificationComponent {

  notifications = [
    { message: 'do work',         date: '28/04/2022' },
    { message: 'come to hall',    date: '28/04/2022' },
    { message: 'party at 2',      date: '28/04/2022' },
    { message: 'teeda avilay',    date: '28/04/2022' },
    { message: 'abel hayene',     date: '28/04/2022' },
    { message: 'zeynu',           date: '28/04/2022' },
    { message: 'tomesagn melak',  date: '28/04/2022' }
  ];

  constructor() {}

  addNotification() {
    // Navigate to an add-notification form or show a modal
    // For now, just an example:
    alert('Add Notification clicked!');
  }

  deleteNotification(index: number) {
    // Remove from array or call an API to delete
    this.notifications.splice(index, 1);
  }
}
