import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-add-employee',
  standalone: false,
  templateUrl: './add-employee.component.html',
  styleUrl: './add-employee.component.css'
})
export class AddEmployeeComponent {
  employeeForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.employeeForm = this.fb.group({
      fullName: ['', Validators.required],
      jobTitle: ['', Validators.required],
      department: ['', Validators.required],
      projectManager: ['', Validators.required],
      contactNumber: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
      skills: ['', Validators.required],
      dob: ['', Validators.required],
      joiningDate: ['', Validators.required],
      team: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      gender: ['', Validators.required],
      profilePhoto: [null, Validators.required]
    });
  }

  onFileSelect(event: any) {
    const file = event.target.files[0];
    this.employeeForm.patchValue({ profilePhoto: file });
  }

  onSubmit() {
    if (this.employeeForm.valid) {
      console.log('Form Submitted:', this.employeeForm.value);
    } else {
      alert('Please fill all fields correctly.');
    }
  }
}
