import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-department',
  standalone: false,
  templateUrl: './department.component.html',
  styleUrl: './department.component.css'
})
export class DepartmentComponent {
  // Example data for departments
  departments = [
    {
      name: 'Software Development',
      totalEmployees: 40,
      description: 'Focuses on developing applications, systems, and software solutions.'
    },
    {
      name: 'IT Infrastructure / Operations',
      totalEmployees: 30,
      description: 'Manages network, hardware, and vital infrastructure, ensuring reliability and performance.'
    },
    {
      name: 'Cybersecurity',
      totalEmployees: 25,
      description: 'Ensures the protection of systems, data, and networks from cyber threats.'
    },
    {
      name: 'Data Science & Analytics',
      totalEmployees: 15,
      description: 'Responsible for data analysis, modeling, and extracting insights from large datasets.'
    },
    {
      name: 'IT Support / Help Desk',
      totalEmployees: 20,
      description: 'Provides technical assistance and troubleshooting for users across the organization.'
    },
    {
      name: 'Quality Assurance (QA)',
      totalEmployees: 10,
      description: 'Oversees the testing and validation of software, ensuring quality standards are met.'
    },
    {
      name: 'Product Management',
      totalEmployees: 20,
      description: 'Manages the development and lifecycle of IT products, ensuring they meet business goals.'
    }
  ];

  constructor(private router: Router) {}

  viewEmployees(dept: any) {
    // Example: navigate to an employees page or show a detail modal
    // For now, just an alert
    alert(`Viewing employees for department: ${dept.name}`);
    // e.g., this.router.navigate(['/employees', dept.name]);
  }
}
