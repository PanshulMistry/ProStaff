import { Component } from '@angular/core';

@Component({
  selector: 'app-employee-management',
  standalone: false,
  templateUrl: './employee-management.component.html',
  styleUrl: './employee-management.component.css'
})
export class EmployeeManagementComponent {
  employees = [
    { id: 22719, name: 'Yeabsire Abebe', department: 'Design', joiningDate: '28/04/2022', jobTitle: 'UI/UX Designer', gender: 'Female' },
    { id: 27413, name: 'Feven Tesfaye', department: 'IT', joiningDate: '28/04/2022', jobTitle: 'Backend Engineer', gender: 'Female' },
    { id: 32147, name: 'AMANUEL BEYENE', department: 'Design', joiningDate: '28/04/2022', jobTitle: 'UI/UX Designer', gender: 'Male' },
    { id: 21647, name: 'Tedla Atalay', department: 'Design', joiningDate: '28/04/2022', jobTitle: 'UI/UX Designer', gender: 'Male' },
    { id: 31492, name: 'Redwan Husein', department: 'Design', joiningDate: '28/04/2022', jobTitle: 'UI/UX Designer', gender: 'Male' },
    { id: 26742, name: 'Abel Beyene', department: 'Design', joiningDate: '28/04/2022', jobTitle: 'UI/UX Designer', gender: 'Male' },
    { id: 31791, name: 'Temesgen Melak', department: 'Design', joiningDate: '28/04/2022', jobTitle: 'UI/UX Designer', gender: 'Male' }
  ];
}
