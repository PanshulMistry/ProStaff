import { Component } from '@angular/core';

@Component({
  selector: 'app-teams',
  standalone: false,
  templateUrl: './teams.component.html',
  styleUrl: './teams.component.css'
})
export class TeamsComponent {
   // Example data for teams
   teams = [
    { name: 'team 1', totalEmployees: 45 },
    { name: 'team 2', totalEmployees: 10 },
    { name: 'team 3', totalEmployees: 23 },
    { name: 'team 4', totalEmployees: 34 },
    { name: 'team 5', totalEmployees: 25 },
    { name: 'team 6', totalEmployees: 29 }
  ];

  constructor() {}

  addTeams() {
    // Example: Navigate to an "Add Team" form or show a modal
    alert('Add Teams button clicked!');
  }

  deleteTeam(index: number) {
    // Remove from array or call an API
    // For now, just an example:
    this.teams.splice(index, 1);
  }
}
