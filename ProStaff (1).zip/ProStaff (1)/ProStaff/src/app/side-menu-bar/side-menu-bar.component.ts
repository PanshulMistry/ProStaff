import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-side-menu-bar',
  standalone: false,
  templateUrl: './side-menu-bar.component.html',
  styleUrl: './side-menu-bar.component.css'
})
export class SideMenuBarComponent {

  @Input() isSidebarOpen = false;

  logout() {
    console.log("Logout clicked");
  }
}
