import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  standalone: false,
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'ProStaff';

  isSidebarOpen = false;

  toggleSidebar() {
    console.log("Sidebar Toggled, new state: ", !this.isSidebarOpen);
    this.isSidebarOpen = !this.isSidebarOpen;
  }
}
