import { Component } from '@angular/core';

@Component({
  selector: 'app-contact-us',
  standalone: false,
  templateUrl: './contact-us.component.html',
  styleUrl: './contact-us.component.css'
})
export class ContactUsComponent {
  contacts = [
    { email: 'query@gmail.com', phone: '079-10205060', description: 'Only for query related' },
    { email: 'help@gmail.com',  phone: '079-50402010', description: 'Only for help related' }
  ];

  updateContact(contact: any) {
    alert(`Updating contact: ${contact.email}`);
  }
}
