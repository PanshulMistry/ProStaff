import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-rough-work',
  standalone: false,
  templateUrl: './rough-work.component.html',
  styleUrl: './rough-work.component.css'
})
export class RoughWorkComponent {
  events = [
    {
      title: 'Annual Function',
      description: 'Our Annual Function is here! Join us for a night of celebration, recognition, and entertainment as we honor the outstanding contributions of our team over the past year.',
      id: 1
    },
    {
      title: 'Annual Function',
      description: 'Our Annual Function is here! Join us for a night of celebration, recognition, and entertainment as we honor the outstanding contributions of our team over the past year.',
      id: 2
    },
    {
      title: 'Annual Function',
      description: 'Our Annual Function is here! Join us for a night of celebration, recognition, and entertainment as we honor the outstanding contributions of our team over the past year.',
      id: 3
    }
  ];

  constructor(private router: Router) {}

  viewDetails(event: any) {
    this.router.navigate(['/events', event.id]);
  }

  editEvent(event: any) {
    this.router.navigate(['/edit-event', event.id]);
  }
}
