import { Component } from '@angular/core';

@Component({
  selector: 'app-home-page',
  standalone: false,
  templateUrl: './home-page.component.html',
  styleUrl: './home-page.component.css'
})
export class HomePageComponent {

  leavesCount = 8; // example

  departments = [
    'Information Technology',
    'UI/UX Design',
    'AWS'
  ];

  teams = [
    'Team Alpha',
    'Team beta',
    'Team Gamma'
  ];

  totalEmployees = {
    male: 172,
    female: 86,
    total: 258
  };

  // Upcoming events now use title and description
  events = [
    {
      title: 'Annual Function',
      description: 'Our Annual Function is here! Join us for a night of celebration, recognition, and entertainment as we honor our team.'
    },
    {
      title: 'Team Outing',
      description: 'Team Outing details go here. Enjoy a day of fun with your colleagues!'
    },
    {
      title: 'Quarterly Meeting',
      description: 'Join us for our quarterly meeting to review performance and set goals.'
    }
  ];

  employees = [
    { name: 'Aman', role: 'Product Manager', image: 'assets/Images/Aryan.jpg' },
    { name: 'Aman', role: 'Teach Lead', image: 'assets/Images/Aryan.jpg' },
    { name: 'Aman', role: 'AI/ML', image: 'assets/Images/Employee.png' }
  ];

  constructor() {}
}
