import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-view-profile',
  standalone: false,
  templateUrl: './view-profile.component.html',
  styleUrl: './view-profile.component.css'
})
export class ViewProfileComponent {
  
  // Profile photo
  profilePhoto = 'assets/Images/Aryan.jpg';

  // Skill Ratings (allow half-stars, e.g. 3.5)
  punctuality = 4;
  performance = 3.5;
  softSkills = 4;
  creativity = 3;

  // The user wants the overall rating to be an average
  getOverallRating(): number {
    const sum = this.punctuality + this.performance + this.softSkills + this.creativity;
    return Math.round((sum / 4) * 10) / 10; // e.g. 3.8 => round to 3.8
  }

  // Returns the star icon (filled, half, empty) based on rating and starIndex
  getStarIcon(rating: number, starIndex: number): string {
    // If rating is >= starIndex => filled star
    // If rating is >= (starIndex - 0.5) => half star
    // else => empty star
    if (rating >= starIndex) {
      return 'assets/Icons/star-filled.png';
    } else if (rating >= starIndex - 0.5) {
      return 'assets/Icons/star-half.png';
    } else {
      return 'assets/Icons/star-empty.png';
    }
  }

  // Single click: Set full star rating
  public setFullRating(skill: string, starIndex: number): void {
    switch (skill) {
      case 'punctuality':
        this.punctuality = starIndex;
        break;
      case 'performance':
        this.performance = starIndex;
        break;
      case 'softSkills':
        this.softSkills = starIndex;
        break;
      case 'creativity':
        this.creativity = starIndex;
        break;
    }
    console.log(`${skill} full rating set to: ${starIndex}`);
  }

  // Double click: Set half star rating
  public setHalfRating(skill: string, starIndex: number): void {
    // This sets the rating to (starIndex - 0.5)
    switch (skill) {
      case 'punctuality':
        this.punctuality = starIndex - 0.5;
        break;
      case 'performance':
        this.performance = starIndex - 0.5;
        break;
      case 'softSkills':
        this.softSkills = starIndex - 0.5;
        break;
      case 'creativity':
        this.creativity = starIndex - 0.5;
        break;
    }
    console.log(`${skill} half rating set to: ${starIndex - 0.5}`);
  }


  // onStarClick(event: MouseEvent, skill: string, starIndex: number) {
  //   // 2a) Find the star's actual width
  //   const target = event.target as HTMLElement;
  //   const starWidth = target.clientWidth; // e.g., 20 px

  //   // 2b) Check the offsetX to see if user clicked left or right half
  //   const offsetX = event.offsetX; // how many px from the left side of star

  //   let newRating: number;
  //   if (offsetX < starWidth / 2) {
  //     // user clicked left half => half star
  //     newRating = starIndex - 0.5;
  //   } else {
  //     // user clicked right half => full star
  //     newRating = starIndex;
  //   }

  //   // 2c) Assign the new rating
  //   switch (skill) {
  //     case 'punctuality':
  //       this.punctuality = newRating;
  //       break;
  //     case 'performance':
  //       this.performance = newRating;
  //       break;
  //     case 'softSkills':
  //       this.softSkills = newRating;
  //       break;
  //     case 'creativity':
  //       this.creativity = newRating;
  //       break;
  //   }
  //   console.log(`New ${skill} rating set to: ${newRating}`);
  // }

  // // Set skill rating when admin clicks a star
  // setSkillRating(skill: string, starIndex: number) {
  //   // If user clicks star #4, that means rating=4
  //   // For half-star on click, you'd need additional logic
  //   switch (skill) {
  //     case 'punctuality':
  //       this.punctuality = starIndex;
  //       break;
  //     case 'performance':
  //       this.performance = starIndex;
  //       break;
  //     case 'softSkills':
  //       this.softSkills = starIndex;
  //       break;
  //     case 'creativity':
  //       this.creativity = starIndex;
  //       break;
  //   }
  // }

  // Left side - changing photo
  changePhoto() {
    // e.g. open file dialog, or show a modal
    alert('Change Profile Photo clicked!');
  }

  // Right side - 12 input fields
  firstName = 'Aryan';
  lastName = 'Sharma';
  gender = 'Male';
  jobTitle = 'Software Engineer';
  // Department dropdown
  departments = ['IT', 'HR', 'Finance', 'Marketing', 'Design'];
  department = 'IT';

  projectManager = 'John Doe';
  // Contact number with pattern
  contactNumber = '9876543210';
  // Email
  email = 'aryan.sharma@example.com';
  // dateOfBirth and joiningDate
  dateOfBirth = '1995-04-10';
  joiningDate = '2021-06-01';
  // Team dropdown
  teamsList = ['Team Alpha', 'Team Beta', 'Team Gamma'];
  team = 'Team Alpha';
  // Skills
  skills = 'Angular, Node.js';

  constructor() {}

  // Save Changes => update DB or show an alert
  saveChanges() {
    // e.g. call an API to save these updated fields
    alert('Profile changes saved to DB!');
  }
}
