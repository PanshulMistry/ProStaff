import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, Observable, throwError } from 'rxjs';
// models/organization-employee.model.ts
export interface OrganizationEmployee {
  fullName: string;
  email: string;
  gender: 'MALE' | 'FEMALE';
  age: number;
  profileImage: string;
  department: string;
  designation: string;
}
export interface Employee {
  email: string;
  fullName: string;
  gender: string;
  skills: string[];
  reportingManager: string;
  phoneNumber: string;
  dob: string;
  profileImage: string;
  joiningDate: string;
  emergencyContact: string;
  bankDetail: {
    bankName: string;
    ifscCode: string;
    accountNumber: string;
    branch: string;
  };
  rating: {
    punctuality: number;
    performance: number;
    softSkills: number;
    creativity: number;
  };
  age: number;
  department: {
    id: number;
    name: string;
    description: string;
    employeeCount: number;
  };
  designation: {
    id: number;
    name: string;
    description: string;
    employeeCount: number;
  };
  teams: Array<{
    id: number;
    name: string;
    description: string;
    employeeCount: number;
  }>;
  address: string;
}
@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  private baseUrl = 'http://localhost:5555';

  constructor(private http: HttpClient,private router:Router) {}

  getAllOrganizationEmployees(adminEmail: string): Observable<OrganizationEmployee[]> {
    const url = `${this.baseUrl}/employee/get-all-organization-employees`;
    const body = { adminEmail };
    return this.http.post<OrganizationEmployee[]>(url, body);
  }

  getEmployeeInformation(employeeEmail: string, token: string): Observable<Employee[]> {
    const url = `${this.baseUrl}/employee/get-employee-information`;
    const body = { employeeEmail };  // Send a single object, not an array
    return this.http.post<Employee[]>(url, body).pipe(
      catchError(this.handleError)
    );
  }

  addEmployee(payload: any): Observable<boolean> {
    return this.http.post<boolean>(`${this.baseUrl}/employee/add-employee`, payload);
  }

  private handleError(error: HttpErrorResponse) {
    console.error('API Error:', error);
    return throwError(() => new Error('Something went wrong; please try again later.'));
  }
}
