import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { EmployeeService } from '../services/employee.service';
import { AuthServiceService } from '../services/auth-service.service';
import { DesignationService } from '../services/designation.service';
import { TeamsService } from '../services/teams.service';
import { DepartmentServiceService } from '../services/department-service.service';

@Component({
  selector: 'app-admin-add-emp',
  standalone:false,
  templateUrl: './admin-add-emp.component.html',
  styleUrl: './admin-add-emp.component.css'
})
export class AdminAddEmpComponent implements OnInit{
adminEmail : string | null = ''
salary =''
  fullName = '';
  contactNumber = '';
  email = '';
  gender = '';
  skills = '';
  dateOfBirth = '';
  joiningDate = '';
  address = '';
  projectManager = '';
  bankName = '';
  ifcCode = '';
  accountNumber = '';
  branchName = '';
  department = '';
  jobTitle = '';
  team = '';
  fileName: string | null = null;
  selectedFile: File | null = null;
  departments: { id: number; name: string }[] = [];
  teamsList: { id: number; name: string }[] = [];
  designationsList: { id: number; name: string }[] = [];
  selectedDepartmentId: number | null = null;
  selectedDesignationId: number | null = null;
  selectedTeamIds: number[] = [];
  ifscCode = ''

  constructor(private employeeService: EmployeeService, private authService: AuthServiceService, private designationService: DesignationService,
    private departmentService: DepartmentServiceService, private teamService: TeamsService
  ) { }

  ngOnInit() {
    this.adminEmail = this.authService.getLoggedInEmail();
    if (!this.adminEmail) return;

    this.designationService.getAllDesignations(this.adminEmail).subscribe((desgs) => {
      this.designationsList = desgs.map(desg => ({
        id: desg.id,
        name: desg.name
      }));
      console.log("designation list:", this.designationsList)
    });

    this.teamService.getAllTeams(this.adminEmail).subscribe((teams) => {
      this.teamsList = teams.map(team => ({
        id: team.id,
        name: team.name
      }));
    });

    this.departmentService.getAllDepartments(this.adminEmail).subscribe((depts) => {
      this.departments = depts.map(dept => ({
        id: dept.id,
        name: dept.name
      }));

    });
  }
  onTeamCheckboxChange(event: any) {
    const value = +event.target.value;
    if (event.target.checked) {
      if (!this.selectedTeamIds.includes(value)) {
        this.selectedTeamIds.push(value);
      }
    } else {
      this.selectedTeamIds = this.selectedTeamIds.filter(id => id !== value);
    }
  }
  
  onFileSelected(event: any): void {
    const file: File = event.target.files[0];

    if (file) {
      this.selectedFile = file;
      this.fileName = file.name;
    }
  }

  cancelUpload(): void {
    this.selectedFile = null;
    this.fileName = '';

    // Also reset the file input field manually
    const fileInput = document.getElementById('fileInput') as HTMLInputElement;
    if (fileInput) {
      fileInput.value = '';
    }
  }

  submitForm(form: NgForm) {
    if (form.invalid) {
      alert('Please fill in all required fields.');
      return;
    }
  
    if (!this.validatePhone(this.contactNumber)) {
      alert('Phone must be 10 digits.');
      return;
    }
  
    if (!this.validateEmail(this.email)) {
      alert('Invalid email format.');
      return;
    }
  
    if (!this.selectedDepartmentId || !this.selectedDesignationId || this.selectedTeamIds.length === 0) {
      alert('Please select department, designation, and at least one team.');
      return;
    }
  
    const employeeData = {
      email: this.email,
      fullName: this.fullName,
      adminEmail: this.adminEmail,
      gender: this.gender,
      skills: this.skills.split(',').map(skill => skill.trim()),
      reportingManager: this.projectManager,
      phoneNumber: this.contactNumber,
      dob: new Date(this.dateOfBirth).toISOString(),
      joiningDate: new Date(this.joiningDate).toISOString(),
      emergencyContact: '0000000000',
      bankDetail: {
        bankName: this.bankName,
        ifscCode: this.ifcCode,
        accountNumber: this.accountNumber,
        branch: this.branchName
      },
      department: this.selectedDepartmentId,
      designation: this.selectedDesignationId,
      teams: this.selectedTeamIds,
      address: this.address
    };
  
    const formData = new FormData();
    formData.append('employeeRegistrationDetail', new Blob([JSON.stringify(employeeData)], { type: 'application/json' }));
  
    if (this.selectedFile) {
      formData.append('profileImage', this.selectedFile);
    }
  
    this.employeeService.addEmployee(formData).subscribe({
      next: (res) => {
        if (res) {
          alert('Employee added successfully!');
          this.resetForm();
          form.resetForm();
        } else {
          alert('Failed to add employee.');
        }
      },
      error: (err) => {
        console.error(err);
        alert('API error occurred!');
      }
    });
  }
  
  

  validatePhone(phone: string): boolean {
    const regex = /^[0-9]{10}$/;
    return regex.test(phone);
  }

  validateEmail(email: string): boolean {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email.toLowerCase());
  }

  resetForm() {
    this.fullName = '';
    this.contactNumber = '';
    this.email = '';
    this.gender = '';
    this.skills = '';
    this.dateOfBirth = '';
    this.joiningDate = '';
    this.address = '';
    this.projectManager = '';
    this.bankName = '';
    this.ifcCode = '';
    this.accountNumber = '';
    this.branchName = '';
    this.department = '';
    this.jobTitle = '';
    this.team = '';
    this.fileName = null;
  }
}
